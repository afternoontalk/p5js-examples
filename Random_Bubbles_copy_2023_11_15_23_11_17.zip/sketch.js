let img;

function setup() {
  createCanvas(600, 600);
  bg = loadImage('image.jpg');
} 

function draw() {
  background(bg);
  for (i = 0; i < 1; i++) {
    fill(random(200, 255), random(60,100), random(10,100));
    ellipse(random(windowWidth), random(windowHeight), 70, 70); 
  } 
}

