let circles = 10; 
let xPositions = [];
let yPositions = [];
let img;

function setup() {
  createCanvas(600, 600);
  img = loadImage('beach.jpg');
  for (let i = 0; i < circles; i++) {
    xPositions[i] = random(width); 
    yPositions[i] = random(0,220); 
  }
}

function draw() {
  image(img, 0, 0, windowWidth, windowHeight);
  fill(250,240,220); 
  stroke(255, 240, 0); 
  strokeWeight(1); 
  
  for (let i = 0; i < circles; i++) {
    let x = xPositions[i];
    let y = yPositions[i];
    ellipse(x, y, 90, 90); 
  }
  
}
